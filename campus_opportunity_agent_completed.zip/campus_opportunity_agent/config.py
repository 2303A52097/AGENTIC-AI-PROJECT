"""Central configuration (reads .env)."""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


class Settings:
    root = ROOT
    data_dir = ROOT / "data"
    output_dir = ROOT / "outputs"

    llm_provider = os.getenv("LLM_PROVIDER", "openrouter" if os.getenv("OPENROUTER_API_KEY") else "openai").lower()
    openai_model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    openrouter_model = os.getenv("OPENROUTER_MODEL", "openai/gpt-4o-mini")
    groq_model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    google_model = os.getenv("GOOGLE_MODEL", "gemini-2.0-flash")
    crewai_model = os.getenv("CREWAI_MODEL", "openrouter/openai/gpt-4o-mini" if os.getenv("OPENROUTER_API_KEY") else "gpt-4o-mini")

    tavily_api_key = os.getenv("TAVILY_API_KEY", "")
    tavily_depth = os.getenv("TAVILY_SEARCH_DEPTH", "basic")
    campus_domains = [d.strip() for d in os.getenv("CAMPUS_DOMAINS", "").split(",") if d.strip()]

    max_searches = int(os.getenv("MAX_SEARCHES", "6"))
    max_agent_steps = int(os.getenv("MAX_AGENT_STEPS", "8"))

    privacy_salt = os.getenv("PRIVACY_SALT", "dev-salt-change-me")
    trace_hide_io = _bool("TRACE_HIDE_IO", False)

    # scoring weights (sum = 1.0)
    weights = {
        "interest": 0.30,
        "skills": 0.25,
        "category": 0.15,
        "eligibility": 0.10,
        "location": 0.08,
        "urgency": 0.07,
        "credibility": 0.05,
    }


settings = Settings()

# LangSmith defaults / privacy switches (must be set before langsmith is used)
os.environ.setdefault("LANGSMITH_PROJECT", os.getenv("LANGSMITH_PROJECT", "campus-opportunity-agent"))
if not os.getenv("LANGSMITH_API_KEY"):
    os.environ["LANGSMITH_TRACING"] = "false"
    os.environ["LANGCHAIN_TRACING_V2"] = "false"
elif _bool("LANGSMITH_TRACING", True):
    os.environ["LANGSMITH_TRACING"] = "true"
    os.environ["LANGCHAIN_TRACING_V2"] = "true"

if settings.trace_hide_io:
    os.environ["LANGSMITH_HIDE_INPUTS"] = "true"
    os.environ["LANGSMITH_HIDE_OUTPUTS"] = "true"


def today() -> date:
    override = os.getenv("TODAY_OVERRIDE")
    return date.fromisoformat(override) if override else date.today()
