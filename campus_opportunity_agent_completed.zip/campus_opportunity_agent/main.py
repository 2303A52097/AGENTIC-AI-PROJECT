"""CLI and Interactive entrypoint for the Campus Event & Opportunity Recommender agent.

Interactive usage:
  python main.py
  python main.py interactive

CLI commands:
  python main.py check
  python main.py run --profile data/profiles/student_asha.json --offline
  python main.py run --profile data/profiles/student_asha.json            (live Tavily + LLM)
  python main.py run --profile data/profiles/student_asha.json --crew     (adds CrewAI layer)
  python main.py evaluate [--langsmith] [--offline] [--judge] [--dataset data/eval_examples.jsonl]
  python main.py forget --user-id STU-2023-0412
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from config import settings
from src.llm import llm_available
from src.schemas import StudentProfile
from src.interactive import run_interactive

console = Console()


def load_profile(path: str, row: int = 0) -> StudentProfile:
    p = Path(path)
    if p.suffix.lower() == ".csv":
        with p.open(newline="", encoding="utf-8") as fh:
            data = list(csv.DictReader(fh))[row]
        for key in ("interests", "skills", "goals", "preferred_categories"):
            data[key] = [x.strip() for x in data.get(key, "").split(";") if x.strip()]
        data["year"] = int(data.get("year", 1) or 1)
        return StudentProfile(**data)
    return StudentProfile(**json.loads(p.read_text(encoding="utf-8")))


def cmd_interactive(_: argparse.Namespace) -> None:
    run_interactive()


def cmd_check(_: argparse.Namespace) -> None:
    table = Table(title="Environment check")
    table.add_column("component"), table.add_column("status")
    table.add_row(f"LLM ({settings.llm_provider})", "[green]key found[/green]" if llm_available() else "[yellow]no key -> heuristic mode[/yellow]")
    table.add_row("Tavily", "[green]key found[/green]" if settings.tavily_api_key else "[yellow]no key -> offline corpus[/yellow]")
    ls = bool(os.getenv("LANGSMITH_API_KEY"))
    table.add_row("LangSmith", "[green]key found[/green]" if ls else "[yellow]no key -> no tracing[/yellow]")
    table.add_row("Trace hide I/O", str(settings.trace_hide_io))
    console.print(table)


def cmd_run(args: argparse.Namespace) -> None:
    from src.pipeline import OpportunityAgent

    profile = load_profile(args.profile, args.row)
    agent = OpportunityAgent(use_llm=not args.no_llm)
    with console.status("Agent running ..."):
        result = agent.run(profile, offline=args.offline, top_k=args.top_k, save=not args.no_save,
                           diversity_lambda=args.diversity)

    console.print(Panel.fit(f"user={result['user']}  source={result['source']}  llm_used={result['llm_used']}\n"
                            f"stats={result['stats']}\nmetrics={result['metrics']}", title="Run summary"))
    table = Table(title=f"Top {len(result['recommendations'])} recommendations", show_lines=True)
    for col in ("#", "Title", "Type", "Deadline", "Score", "Why"):
        table.add_column(col)
    for i, rec in enumerate(result["recommendations"], 1):
        o = rec["opportunity"]
        table.add_row(str(i), o["title"], o["category"], o["deadline"] or "-", f"{rec['score']:.2f}", rec["reason"])
    console.print(table)
    if "saved_to" in result:
        console.print("Saved: " + ", ".join(result["saved_to"]), markup=False)
    else:
        console.print("[yellow]Nothing saved (user did not consent to storage or --no-save).[/yellow]")

    if args.crew:
        from src.crew_agents import run_crew
        from src.privacy import build_safe_profile
        console.print(Panel(run_crew(build_safe_profile(profile), result), title="CrewAI action plan"))


def cmd_evaluate(args: argparse.Namespace) -> None:
    from src.evaluation.run_eval import main as eval_main

    eval_main(
        langsmith=args.langsmith,
        use_llm=not args.no_llm,
        offline=args.offline or not settings.tavily_api_key,
        top_k=args.top_k,
        judge=args.judge,
        dataset=args.dataset,
    )


def cmd_forget(args: argparse.Namespace) -> None:
    from src.privacy import forget_user

    removed = forget_user(args.user_id)
    console.print(f"Deleted {len(removed)} stored file(s) for this user." if removed else "No stored data found for this user.")


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Campus Event & Opportunity Recommender (agentic AI)")
    sub = ap.add_subparsers(dest="cmd")

    sub.add_parser("interactive", help="run interactive prompt session").set_defaults(fn=cmd_interactive)
    sub.add_parser("check", help="show which API keys are configured").set_defaults(fn=cmd_check)

    r = sub.add_parser("run", help="recommend opportunities for one profile")
    r.add_argument("--profile", required=True, help="path to .json or .csv profile")
    r.add_argument("--row", type=int, default=0, help="row index when using CSV")
    r.add_argument("--offline", action="store_true", help="use the bundled sample corpus (no Tavily)")
    r.add_argument("--no-llm", action="store_true", help="skip the LLM (rule-based extraction/explanations)")
    r.add_argument("--no-save", action="store_true")
    r.add_argument("--crew", action="store_true", help="add the optional CrewAI multi-agent plan")
    r.add_argument("--top-k", type=int, default=8)
    r.add_argument("--diversity", type=float, default=0.7, help="MMR lambda: 1.0 = pure relevance, lower = more diverse")
    r.set_defaults(fn=cmd_run)

    e = sub.add_parser("evaluate", help="relevance + diversity evaluation on the dataset")
    e.add_argument("--langsmith", action="store_true", help="upload dataset & run experiment in LangSmith")
    e.add_argument("--offline", action="store_true", help="evaluate on the fixed sample corpus (reproducible)")
    e.add_argument("--no-llm", action="store_true")
    e.add_argument("--judge", action="store_true", help="add LLM-as-judge relevance evaluator")
    e.add_argument("--top-k", type=int, default=5)
    e.add_argument("--dataset", type=str, default=None, help="path to custom dataset (.json or .jsonl)")
    e.set_defaults(fn=cmd_evaluate)

    f = sub.add_parser("forget", help="delete all stored data of a user (right to be forgotten)")
    f.add_argument("--user-id", required=True)
    f.set_defaults(fn=cmd_forget)
    return ap


if __name__ == "__main__":
    if len(sys.argv) == 1:
        run_interactive()
    else:
        args = build_parser().parse_args()
        if hasattr(args, "fn"):
            sys.exit(args.fn(args))
        else:
            run_interactive()
