"""Campus Opportunity AI Agent - Direct Interactive Launcher.
Run with:
    python run_agent.py
"""
import sys
from pathlib import Path

# Add project root to sys.path
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.interactive import run_interactive

if __name__ == "__main__":
    run_interactive()
