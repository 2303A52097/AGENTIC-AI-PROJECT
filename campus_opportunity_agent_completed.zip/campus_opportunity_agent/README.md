# Campus Event & Opportunity Recommender - Agentic AI project

An autonomous Python agent that reads a student profile, searches the web/campus sources with **Tavily**,
extracts and cleans opportunities (events, internships, hackathons, workshops, clubs, scholarships),
ranks them for the student, **protects private data**, traces everything with **LangSmith** and evaluates
**relevance + diversity** on a **LangSmith dataset**. Optional **CrewAI** multi-agent layer included.
Pure Python - no website.

## Architecture
```
 profile.json/.csv (PII + consent flags)
        |
 [1 Privacy gate]  -> SafeProfile (no name/email/phone/ID), pseudonymous id, consent policy
        |
 [2 Scout agent]   -> LangChain tool-calling loop (LLM picks queries) -> Tavily / campus-domain search
        |              fallback: deterministic query planner  |  offline sample corpus (no keys)
 [3 Extractor]     -> LLM structured output (Pydantic) | rule-based fallback
        |
 [4 Cleaner]       -> URL normalisation + fuzzy duplicate removal + expired/non-opportunity filter
        |
 [5 Matcher]       -> explainable score: interest, skills, category, eligibility, location, urgency, credibility
        |
 [6 Diversifier]   -> MMR re-ranking (relevance vs. redundancy)
        |
 [7 Explainer]     -> LLM "why this fits you" (template fallback)
        |
 [8 Output guard]  -> blocks run if any private identifier leaked
        |
 [9 Storage]       -> only if consent.store_results; audit log (pseudonymous); `forget` command
        |
 Optional: CrewAI crew (Scout -> Analyst -> Advisor) writes the action plan

 LangSmith: every step is a span (PII-anonymised) + dataset + experiments (relevance & diversity)
```

## Setup (VS Code terminal)
```bash
python -m venv .venv
# Windows PowerShell:  .venv\Scripts\Activate.ps1      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # Windows: copy .env.example .env   -> then fill in your keys
python main.py check
```

## Run
```bash
python -m pytest -q                                                        # unit tests (no keys needed)
python main.py run --profile data/profiles/student_asha.json --offline --no-llm   # demo, no API keys
python main.py run --profile data/profiles/student_asha.json               # live: Tavily + LLM + LangSmith
python main.py run --profile data/profiles/student_asha.json --crew        # + CrewAI action plan
python main.py run --profile data/profiles/student_ravi_private.json --offline   # privacy: no LLM/search/storage
python main.py run --profile data/profiles/profiles.csv --row 0 --offline  # CSV profile
python main.py evaluate --offline --no-llm                                 # local metrics table
python main.py evaluate --langsmith --offline --judge                      # dataset + experiment in LangSmith
python main.py forget --user-id STU-2023-0412                              # delete stored data of a user
```

## Privacy controls
| Control | Where |
|---|---|
| Consent flags per user (`share_with_llm`, `share_with_search`, `use_location`, `store_results`) | profile JSON |
| Data minimisation: only a PII-free `SafeProfile` reaches LLM / Tavily / LangSmith | `src/privacy.py` |
| Regex redaction (email, phone, Aadhaar, roll no.) of queries and scraped text | `redact_text` |
| Salted-hash pseudonymous id used in file names, logs, traces | `pseudonymize` |
| LangSmith: input processor logs only the pseudonym; regex anonymiser; `TRACE_HIDE_IO=true` hides all I/O | `tracing.py`, `pipeline.py` |
| Output guard blocks results that contain private identifiers | `pipeline.py` |
| Storage only with consent, append-only audit log, right-to-be-forgotten | `privacy.py` |

## Evaluation (LangSmith dataset `campus-opportunity-eval-v1`)
Inputs = synthetic profiles (contain fake PII on purpose), reference outputs = relevant tags/categories.
Evaluators: `precision_at_k`, `ndcg`, `eligibility_ok`, `category_coverage`, `intra_list_diversity`,
`category_entropy`, `source_diversity`, `duplicate_free`, `not_expired`, `privacy_safe`, optional `llm_relevance_judge`.
Experiment idea for your report: compare `--diversity 1.0` (pure relevance) vs `0.7` vs `0.5` and plot the trade-off.

## Project layout
```
main.py            CLI            config.py        settings from .env
src/privacy.py     consent, redaction, audit      src/collector.py  Scout agent (Tavily)
src/extractor.py   structured extraction          src/dedupe.py     cleaning
src/matcher.py     scoring                        src/diversity.py  MMR + diversity metrics
src/recommender.py explanations                   src/pipeline.py   orchestrator
src/crew_agents.py CrewAI layer                   src/evaluation/   evaluators + LangSmith runner
data/              profiles, sample corpus, eval dataset      tests/   pytest suite
```

## Ideas to extend
Embeddings (FAISS/Chroma) for semantic matching, scheduled runs with email/Telegram digest, LangGraph state machine,
feedback loop (thumbs up/down stored in a LangSmith dataset), calendar (.ics) export.
