import json
from datetime import date, timedelta
from types import SimpleNamespace

import pytest

from src import privacy
from src.dedupe import dedupe_and_filter, normalize_url
from src.diversity import intra_list_diversity, mmr_rerank
from src.evaluation import evaluators as ev
from src.extractor import extract_all, heuristic_extract
from src.matcher import rank
from src.pipeline import OpportunityAgent
from src.schemas import Opportunity, StudentProfile
from src.collector import load_offline_corpus

PROFILE = StudentProfile(
    user_id="STU-1", name="Asha Verma", email="asha@example.com", phone="+91 98765 43210",
    city="Hyderabad", college="Example Institute", degree="B.Tech CS", year=3,
    interests=["agentic ai", "machine learning"], skills=["python", "langchain"],
    preferred_categories=["internship", "hackathon"],
)


# ------------------------------------------------------------------ privacy
def test_redaction_removes_pii():
    text = "Mail asha@example.com or call +91 98765 43210, roll 21AB1A0501, Aadhaar 1234 5678 9012"
    out = privacy.redact_text(text)
    for secret in ("asha@example.com", "98765", "21AB1A0501", "1234 5678 9012"):
        assert secret not in out


def test_safe_profile_has_no_pii():
    safe = privacy.build_safe_profile(PROFILE)
    dumped = safe.model_dump_json().lower()
    for secret in ("asha", "verma", "example.com", "98765", "stu-1"):
        assert secret not in dumped
    assert safe.pseudo_id.startswith("u_")


def test_location_consent_respected():
    p = PROFILE.model_copy(update={"consent": PROFILE.consent.model_copy(update={"use_location": False})})
    safe = privacy.build_safe_profile(p)
    assert safe.city == "" and safe.college == ""


def test_pseudonym_is_stable_and_not_reversible():
    assert privacy.pseudonymize("STU-1") == privacy.pseudonymize("STU-1")
    assert "STU-1" not in privacy.pseudonymize("STU-1")


# ------------------------------------------------------------- extraction/dedupe
def test_heuristic_extraction_dates():
    d = (date.today() + timedelta(days=20)).strftime("%d %B %Y")
    opp = heuristic_extract({"title": "ML Internship", "url": "https://x.example.com/a",
                             "content": f"Machine learning internship. Python. Apply by {d}. Remote."})
    assert opp.category == "internship" and opp.deadline == (date.today() + timedelta(days=20)).isoformat()
    assert opp.mode == "online" and "python" in opp.tags


def test_blog_post_is_filtered():
    opps = extract_all(load_offline_corpus(), llm=None)
    assert all("Study Better" not in o.title for o in opps)


def test_url_normalisation():
    assert normalize_url("https://www.a.com/x/?utm_source=z") == normalize_url("https://a.com/x")


def test_dedupe_and_expiry():
    opps = extract_all(load_offline_corpus(), llm=None)
    clean, stats = dedupe_and_filter(opps, date.today())
    assert stats["duplicates_removed"] >= 2        # BuildAgents x2 + Nimbus x2
    assert stats["expired_removed"] >= 1           # research internship closed
    assert len({normalize_url(o.url) for o in clean}) == len(clean)


# ------------------------------------------------------------ ranking/diversity
def test_matching_prefers_relevant_items():
    opps, _ = dedupe_and_filter(extract_all(load_offline_corpus(), None), date.today())
    ranked = rank(opps, privacy.build_safe_profile(PROFILE), date.today())
    top_titles = " ".join(r.opportunity.title for r in ranked[:4]).lower()
    assert "langchain" in top_titles or "ml" in top_titles or "buildagents" in top_titles


def test_mmr_improves_or_keeps_diversity():
    opps, _ = dedupe_and_filter(extract_all(load_offline_corpus(), None), date.today())
    ranked = rank(opps, privacy.build_safe_profile(PROFILE), date.today())
    relevance_only = [r.opportunity for r in mmr_rerank(ranked, 6, lam=1.0)]
    diverse = [r.opportunity for r in mmr_rerank(ranked, 6, lam=0.5)]
    assert intra_list_diversity(diverse) >= intra_list_diversity(relevance_only)


# ------------------------------------------------------------------ end-to-end
def test_pipeline_offline_end_to_end(tmp_path, monkeypatch):
    monkeypatch.setattr("src.report.settings.output_dir", tmp_path)
    monkeypatch.setattr("src.privacy.AUDIT_FILE", tmp_path / "audit.jsonl")
    result = OpportunityAgent(use_llm=False).run(PROFILE, offline=True, top_k=6)
    assert 1 <= len(result["recommendations"]) <= 6
    assert result["privacy"]["leaks_found"] == 0
    blob = json.dumps(result).lower()
    assert "asha" not in blob and "98765" not in blob
    assert "saved_to" in result


def test_no_storage_without_consent(tmp_path, monkeypatch):
    monkeypatch.setattr("src.report.settings.output_dir", tmp_path)
    monkeypatch.setattr("src.privacy.AUDIT_FILE", tmp_path / "audit.jsonl")
    p = PROFILE.model_copy(update={"consent": PROFILE.consent.model_copy(update={"store_results": False})})
    result = OpportunityAgent(use_llm=False).run(p, offline=True)
    assert "saved_to" not in result
    assert not list(tmp_path.glob("u_*"))


def test_forget_user(tmp_path, monkeypatch):
    monkeypatch.setattr("src.report.settings.output_dir", tmp_path)
    monkeypatch.setattr("src.privacy.settings.output_dir", tmp_path)
    monkeypatch.setattr("src.privacy.AUDIT_FILE", tmp_path / "audit.jsonl")
    OpportunityAgent(use_llm=False).run(PROFILE, offline=True)
    assert privacy.forget_user("STU-1")
    assert not list(tmp_path.glob("u_*"))


def test_evaluators_run():
    result = OpportunityAgent(use_llm=False).run(PROFILE, offline=True, top_k=5, save=False)
    run = SimpleNamespace(outputs=result)
    example = SimpleNamespace(inputs={"profile": PROFILE.model_dump()},
                              outputs={"relevant_tags": ["python", "machine learning"], "relevant_categories": ["internship", "hackathon"]})
    assert 0 <= ev.precision_at_k(run, example)["score"] <= 1
    assert ev.privacy_safe(run, example)["score"] == 1.0
    assert ev.duplicate_free(run, example)["score"] == 1.0
    assert len(ev.diversity_scores(run, example)["results"]) == 4
