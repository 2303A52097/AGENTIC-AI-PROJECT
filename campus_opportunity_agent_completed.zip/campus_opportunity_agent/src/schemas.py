"""Pydantic data models shared by every component."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field

Category = Literal["event", "internship", "club", "scholarship", "hackathon", "workshop", "other"]
Mode = Literal["online", "offline", "hybrid", "unknown"]


class ConsentSettings(BaseModel):
    """User-controlled privacy switches (stored inside the profile)."""
    share_with_llm: bool = True      # allow (redacted) profile summary to go to the LLM API
    share_with_search: bool = True   # allow search queries derived from the profile to go to Tavily
    use_location: bool = True        # allow college/city to be used for matching & queries
    store_results: bool = True       # allow saving recommendations on disk


class StudentProfile(BaseModel):
    """FULL profile - contains PII and NEVER leaves the machine."""
    user_id: str
    name: str = ""
    email: str = ""
    phone: str = ""
    college: str = ""
    city: str = ""
    degree: str = ""
    year: int = 1
    interests: list[str] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    goals: list[str] = Field(default_factory=list)
    preferred_categories: list[str] = Field(default_factory=list)
    consent: ConsentSettings = Field(default_factory=ConsentSettings)


class SafeProfile(BaseModel):
    """Minimised, PII-free view that is allowed to reach the LLM / Tavily / traces."""
    pseudo_id: str
    degree: str = ""
    year: int = 1
    interests: list[str] = Field(default_factory=list)
    skills: list[str] = Field(default_factory=list)
    goals: list[str] = Field(default_factory=list)
    preferred_categories: list[str] = Field(default_factory=list)
    college: str = ""   # empty when use_location = False
    city: str = ""      # empty when use_location = False


class Opportunity(BaseModel):
    is_opportunity: bool = Field(True, description="False if the page is not an actual event/internship/club/scholarship")
    title: str = ""
    category: Category = "other"
    organization: str = ""
    url: str = ""
    summary: str = Field("", description="1-2 sentence neutral summary")
    deadline: Optional[str] = Field(None, description="Application/registration deadline, ISO date YYYY-MM-DD")
    event_date: Optional[str] = Field(None, description="Event start date, ISO date YYYY-MM-DD")
    location: str = ""
    mode: Mode = "unknown"
    tags: list[str] = Field(default_factory=list, description="lowercase skill/topic keywords")
    eligibility_years: list[int] = Field(default_factory=list, description="Eligible study years; empty = all")
    source_domain: str = ""


class Recommendation(BaseModel):
    opportunity: Opportunity
    score: float
    score_breakdown: dict[str, float] = Field(default_factory=dict)
    reason: str = ""
