"""Privacy layer: consent gate, PII redaction, pseudonymisation, audit log, right-to-be-forgotten.

Principle = DATA MINIMISATION: the LLM, Tavily and LangSmith only ever see a SafeProfile
(no name / email / phone / roll-number) and redacted text.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone

from config import settings
from src.schemas import SafeProfile, StudentProfile

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d{1,3}[\s\-]?)?(?:\d[\s\-]?){9,11}\d(?!\d)")
AADHAAR_RE = re.compile(r"(?<!\d)\d{4}\s?\d{4}\s?\d{4}(?!\d)")
ROLLNO_RE = re.compile(r"\b\d{2}[A-Za-z]{2,4}\d[A-Za-z]\d{2,4}\b")

AUDIT_FILE = settings.output_dir / "audit_log.jsonl"


# ------------------------------------------------------------------ redaction
def redact_text(text: str, known_values: list[str] | None = None) -> str:
    """Remove emails, phones, ID numbers and any explicitly known private values."""
    if not text:
        return text
    out = EMAIL_RE.sub("[EMAIL]", text)
    out = AADHAAR_RE.sub("[ID]", out)
    out = ROLLNO_RE.sub("[ID]", out)
    out = PHONE_RE.sub("[PHONE]", out)
    for value in known_values or []:
        if value and len(value) > 2:
            out = re.sub(re.escape(value), "[REDACTED]", out, flags=re.IGNORECASE)
    return out


def pseudonymize(user_id: str) -> str:
    """Salted one-way hash -> stable pseudonymous id used in traces, file names, logs."""
    digest = hashlib.sha256(f"{settings.privacy_salt}:{user_id}".encode()).hexdigest()
    return f"u_{digest[:12]}"


def private_values(profile: StudentProfile) -> list[str]:
    values = [profile.name, profile.email, profile.phone, profile.user_id]
    values += [p for p in profile.name.split() if len(p) > 2]
    return [v for v in values if v]


# ----------------------------------------------------------- minimised profile
def build_safe_profile(profile: StudentProfile) -> SafeProfile:
    """Create the PII-free view. Free-text lists are redacted too (users sometimes type PII there)."""
    pv = private_values(profile)
    clean = lambda items: [redact_text(i, pv) for i in items]  # noqa: E731
    use_loc = profile.consent.use_location
    return SafeProfile(
        pseudo_id=pseudonymize(profile.user_id),
        degree=redact_text(profile.degree, pv),
        year=profile.year,
        interests=clean(profile.interests),
        skills=clean(profile.skills),
        goals=clean(profile.goals),
        preferred_categories=clean(profile.preferred_categories),
        college=redact_text(profile.college, pv) if use_loc else "",
        city=redact_text(profile.city, pv) if use_loc else "",
    )


def runtime_policy(profile: StudentProfile) -> dict:
    """Translate consent flags into what the pipeline is allowed to do."""
    c = profile.consent
    return {
        "allow_llm": c.share_with_llm,
        "allow_web_search": c.share_with_search,
        "allow_storage": c.store_results,
        "allow_location": c.use_location,
    }


# --------------------------------------------------------------- leak detector
def find_leaks(text: str, profile: StudentProfile) -> list[str]:
    """Return strict identifiers of the profile (full name, email, phone, user id) found inside `text`.

    Single name parts are NOT checked here (they cause false positives such as "student");
    they are still removed from every profile field by redact_text().
    """
    low = text.lower()
    leaks = [v for v in (profile.name, profile.email, profile.user_id) if v and len(v) > 2 and v.lower() in low]
    digits = re.sub(r"\D", "", profile.phone or "")
    if len(digits) >= 10 and digits[-10:] in re.sub(r"\D", "", text):
        leaks.append("phone")
    return sorted(set(leaks))


# ----------------------------------------------------------------- audit trail
def audit(pseudo_id: str, action: str, **details) -> None:
    """Append-only audit log. Contains pseudonymous ids only - never PII."""
    settings.output_dir.mkdir(parents=True, exist_ok=True)
    entry = {"ts": datetime.now(timezone.utc).isoformat(), "user": pseudo_id, "action": action, **details}
    with AUDIT_FILE.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")


# ------------------------------------------------------ right to be forgotten
def forget_user(user_id: str) -> list[str]:
    """Delete every stored artefact for this user (outputs/<pseudo_id>_*)."""
    pid = pseudonymize(user_id)
    removed = []
    for path in settings.output_dir.glob(f"{pid}_*"):
        path.unlink()
        removed.append(path.name)
    audit(pid, "forget_user", files_removed=len(removed))
    return removed


# ------------------------------------------------------- LangSmith anonymiser
def langsmith_anonymizer():
    """Regex anonymiser applied to every trace sent by our LangSmith client."""
    try:
        from langsmith.anonymizer import create_anonymizer
    except Exception:  # older langsmith versions
        return None
    return create_anonymizer(
        [
            {"pattern": EMAIL_RE.pattern, "replace": "[EMAIL]"},
            {"pattern": AADHAAR_RE.pattern, "replace": "[ID]"},
            {"pattern": ROLLNO_RE.pattern, "replace": "[ID]"},
            {"pattern": PHONE_RE.pattern, "replace": "[PHONE]"},
        ]
    )
