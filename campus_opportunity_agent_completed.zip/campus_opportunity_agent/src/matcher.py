"""Matching step: explainable multi-factor scoring of Opportunity vs SafeProfile."""
from __future__ import annotations

from datetime import date

from config import settings
from src.schemas import Opportunity, Recommendation, SafeProfile
from src.tracing import trace

EDU_SUFFIXES = (".edu", ".ac.in", ".edu.in", ".ac.uk")
TRUSTED_PLATFORMS = ("linkedin.com", "unstop.com", "devpost.com", "internshala.com", "github.com", "kaggle.com")


def _text(o: Opportunity) -> str:
    return f"{o.title} {o.summary} {' '.join(o.tags)} {o.organization}".lower()


SYNONYMS = {
    "agentic ai": ["agent", "llm", "langchain"], "machine learning": ["ml ", "deep learning", "pytorch", "tensorflow"],
    "web development": ["react", "javascript", "frontend"], "startups": ["startup", "entrepreneur"],
    "embedded systems": ["embedded", "iot"], "cybersecurity": ["ctf", "security"], "cloud": ["aws", "docker"],
}


def _stem(term: str) -> str:
    return term[:-1] if term.endswith("s") and len(term) > 4 else term


def _coverage(terms: list[str], text: str, tags: set[str], cap: int = 3) -> float:
    """Fraction of the user's terms found in the opportunity (capped so 3 hits = full score)."""
    terms = [t.lower().strip() for t in terms if t.strip()]
    if not terms:
        return 0.5
    text = text + " "
    hits = 0
    for t in terms:
        variants = [_stem(t)] + SYNONYMS.get(t, []) + [w for w in t.split() if len(w) > 4]
        if t in text or t in tags or any(v in text or v in tags for v in variants):
            hits += 1
    return min(1.0, hits / min(len(terms), cap))


def score_opportunity(o: Opportunity, sp: SafeProfile, today: date) -> tuple[float, dict[str, float]]:
    text, tags = _text(o), {t.lower() for t in o.tags}

    interest = _coverage(sp.interests + sp.goals, text, tags)
    skills = _coverage(sp.skills, text, tags)
    category = 1.0 if o.category in sp.preferred_categories else (0.5 if not sp.preferred_categories else 0.25)

    if not o.eligibility_years:
        eligibility = 0.7
    else:
        eligibility = 1.0 if sp.year in o.eligibility_years else 0.1

    if o.mode == "online":
        location = 0.8
    elif sp.city and sp.city.lower() in (o.location or "").lower():
        location = 1.0
    elif o.mode == "unknown" or not o.location:
        location = 0.5
    else:
        location = 0.2

    if o.deadline:
        days = (date.fromisoformat(o.deadline) - today).days
        urgency = 1.0 if 3 <= days <= 30 else 0.6 if days > 30 else 0.5
    else:
        urgency = 0.4

    d = o.source_domain
    credibility = 1.0 if d.endswith(EDU_SUFFIXES) or d in settings.campus_domains else (0.7 if d in TRUSTED_PLATFORMS else 0.5)

    parts = {"interest": interest, "skills": skills, "category": category, "eligibility": eligibility,
             "location": location, "urgency": urgency, "credibility": credibility}
    total = sum(settings.weights[k] * v for k, v in parts.items())
    return round(total, 4), {k: round(v, 2) for k, v in parts.items()}


@trace("match_and_score", run_type="chain")
def rank(opps: list[Opportunity], sp: SafeProfile, today: date) -> list[Recommendation]:
    recs = []
    for o in opps:
        total, parts = score_opportunity(o, sp, today)
        recs.append(Recommendation(opportunity=o, score=total, score_breakdown=parts))
    return sorted(recs, key=lambda r: r.score, reverse=True)
