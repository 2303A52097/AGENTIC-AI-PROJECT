"""LangSmith tracing helpers. Every pipeline step is a named span; traces are PII-anonymised."""
from __future__ import annotations

import os
from functools import lru_cache

from langsmith import traceable

from src.privacy import langsmith_anonymizer


def tracing_enabled() -> bool:
    flag = (os.getenv("LANGSMITH_TRACING") or os.getenv("LANGCHAIN_TRACING_V2") or "").lower()
    return flag in {"1", "true", "yes"} and bool(os.getenv("LANGSMITH_API_KEY") or os.getenv("LANGCHAIN_API_KEY"))


@lru_cache(maxsize=1)
def get_client():
    """LangSmith client with the privacy anonymiser attached (None if tracing is off)."""
    if not tracing_enabled():
        return None
    from langsmith import Client

    anonymizer = langsmith_anonymizer()
    return Client(anonymizer=anonymizer) if anonymizer else Client()


def trace(name: str, run_type: str = "chain", **kwargs):
    """Decorator: @trace("extract") -> LangSmith span (no-op when tracing is disabled)."""
    client = get_client()
    if client is not None:
        kwargs["client"] = client
    return traceable(name=name, run_type=run_type, **kwargs)
