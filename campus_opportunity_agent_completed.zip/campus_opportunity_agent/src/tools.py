"""Tools the Scout agent can call (LangChain tools)."""
from __future__ import annotations

from langchain_core.tools import tool

from config import settings
from src.privacy import redact_text


def search_tavily(query: str, max_results: int = 5, include_domains: list[str] | None = None) -> list[dict]:
    """Plain Python wrapper around Tavily. The query is always redacted before leaving the machine."""
    from tavily import TavilyClient

    client = TavilyClient(api_key=settings.tavily_api_key)
    kwargs = dict(query=redact_text(query), max_results=max_results, search_depth=settings.tavily_depth)
    if include_domains:
        kwargs["include_domains"] = include_domains
    response = client.search(**kwargs)
    return [
        {"title": r.get("title", ""), "url": r.get("url", ""), "content": r.get("content", ""),
         "score": r.get("score", 0.0), "query": query}
        for r in response.get("results", [])
    ]


@tool
def tavily_search(query: str, max_results: int = 5) -> list[dict]:
    """Search the web for campus events, internships, hackathons, workshops, clubs and scholarships.
    Use specific queries (topic + opportunity type + year). Never include personal identifiers."""
    return search_tavily(query, max_results=min(max_results, 8))


@tool
def campus_site_search(query: str, max_results: int = 5) -> list[dict]:
    """Search ONLY the configured campus domains (college blogs, club pages, placement-cell sites)."""
    if not settings.campus_domains:
        return [{"title": "", "url": "", "content": "No campus domains configured.", "score": 0, "query": query}]
    return search_tavily(query, max_results=min(max_results, 8), include_domains=settings.campus_domains)
