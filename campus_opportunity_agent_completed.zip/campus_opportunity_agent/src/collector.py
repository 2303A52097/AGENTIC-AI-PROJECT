"""Scout step: collect raw search results (agentic Tavily search, deterministic fallback, offline corpus)."""
from __future__ import annotations

import json
import re
from datetime import timedelta

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage

from config import settings, today
from src.schemas import SafeProfile
from src.tools import campus_site_search, tavily_search
from src.tracing import trace

OFFLINE_FILE = settings.data_dir / "sample_search_results.json"


# --------------------------------------------------------------- query planning
def plan_queries(sp: SafeProfile, max_queries: int | None = None) -> list[str]:
    """Deterministic query planner (also the fallback when the LLM agent is unavailable)."""
    max_queries = max_queries or settings.max_searches
    year = today().year
    cats = sp.preferred_categories or ["internship", "event", "club"]
    queries: list[str] = []
    for i, interest in enumerate(sp.interests[:3]):
        cat = cats[i % len(cats)]
        queries.append(f"{interest} {cat} for {sp.degree or 'engineering'} students {year} apply")
    if sp.college and sp.city:
        queries.append(f"{sp.city} college events hackathons workshops {year}")
    for skill in sp.skills[:2]:
        queries.append(f"{skill} internship for students {year}")
    queries.append(f"student scholarships {year} {sp.degree or 'engineering'} deadline")
    seen, uniq = set(), []
    for q in queries:
        if q.lower() not in seen:
            seen.add(q.lower())
            uniq.append(q)
    return uniq[:max_queries]


# ------------------------------------------------------------------ agentic scout
SCOUT_SYSTEM = (
    "You are the SCOUT agent of a campus opportunity recommender. Goal: discover real, currently open "
    "events, internships, hackathons, workshops, clubs and scholarships for the student described below. "
    "Use the tools. Run between 3 and {n} searches with DIFFERENT queries covering different categories and "
    "interests (use campus_site_search first when campus domains exist). Include the year {year} in queries. "
    "Never include personal identifiers. When you have enough coverage reply with exactly: DONE"
)


@trace("scout_agent_loop", run_type="chain")
def agentic_search(sp: SafeProfile, llm, max_searches: int) -> list[dict]:
    """Tool-calling loop: the LLM decides WHICH queries to run, we execute them and feed results back."""
    tools = [campus_site_search, tavily_search] if settings.campus_domains else [tavily_search]
    registry = {t.name: t for t in tools}
    model = llm.bind_tools(tools)
    messages = [
        SystemMessage(content=SCOUT_SYSTEM.format(n=max_searches, year=today().year)),
        HumanMessage(content="Student profile (anonymous):\n" + sp.model_dump_json(indent=1)),
    ]
    collected: list[dict] = []
    searches = 0
    for _ in range(settings.max_agent_steps):
        ai = model.invoke(messages)
        messages.append(ai)
        if not ai.tool_calls:
            break
        for call in ai.tool_calls:
            if call["name"] in registry and searches < max_searches:
                try:
                    results = registry[call["name"]].invoke(call["args"])
                except Exception as exc:  # tool failure must not crash the agent
                    results, note = [], f"tool error: {exc}"
                else:
                    note = ""
                searches += 1
                collected.extend(results)
                payload = json.dumps([{"title": r["title"], "url": r["url"], "snippet": r["content"][:160]} for r in results])
                content = payload if not note else note
            else:
                content = "Search budget exhausted. Reply DONE."
            messages.append(ToolMessage(content=content, tool_call_id=call["id"]))
    return collected


@trace("scout_planned_search", run_type="chain")
def planned_search(sp: SafeProfile, max_searches: int) -> list[dict]:
    from src.tools import search_tavily

    collected = []
    for q in plan_queries(sp, max_searches):
        try:
            collected.extend(search_tavily(q, max_results=5))
        except Exception as exc:
            print(f"[warn] Tavily query failed ({q!r}): {exc}")
    return collected


# ----------------------------------------------------------------- offline corpus
def load_offline_corpus() -> list[dict]:
    """Sample corpus with relative dates ({d+30} = today + 30 days) so the demo never goes stale."""
    raw = OFFLINE_FILE.read_text(encoding="utf-8")

    def repl(match: re.Match) -> str:
        return (today() + timedelta(days=int(match.group(1)))).strftime("%d %B %Y").lstrip("0")

    return json.loads(re.sub(r"\{d([+-]\d+)\}", repl, raw))


@trace("collect", run_type="chain")
def collect(sp: SafeProfile, llm=None, offline: bool = False, allow_web: bool = True) -> tuple[list[dict], str]:
    """Return (raw_results, source_label)."""
    if offline or not allow_web or not settings.tavily_api_key:
        return load_offline_corpus(), "offline-corpus"
    if llm is not None:
        try:
            results = agentic_search(sp, llm, settings.max_searches)
            if results:
                return results, "tavily-agentic"
        except Exception as exc:
            print(f"[warn] agentic scout failed, using planned queries: {exc}")
    return planned_search(sp, settings.max_searches), "tavily-planned"
