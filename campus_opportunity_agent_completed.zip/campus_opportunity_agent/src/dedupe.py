"""Cleaning step: duplicate removal + expired / irrelevant filtering."""
from __future__ import annotations

import re
from datetime import date
from difflib import SequenceMatcher
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from src.schemas import Opportunity
from src.tracing import trace

TRACKING_PARAMS = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "ref", "fbclid", "gclid"}


def normalize_url(url: str) -> str:
    p = urlparse(url.strip())
    query = urlencode([(k, v) for k, v in parse_qsl(p.query) if k.lower() not in TRACKING_PARAMS])
    host = p.netloc.lower().removeprefix("www.")
    return urlunparse(("https", host, p.path.rstrip("/"), "", query, ""))


def normalize_title(title: str) -> str:
    t = re.sub(r"[^a-z0-9 ]", " ", title.lower())
    t = re.sub(r"\b(the|a|an|at|for|of|and|2025|2026|2027)\b", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def is_duplicate(a: Opportunity, b: Opportunity, threshold: float = 0.82) -> bool:
    if normalize_url(a.url) == normalize_url(b.url):
        return True
    ratio = SequenceMatcher(None, normalize_title(a.title), normalize_title(b.title)).ratio()
    if ratio >= threshold:
        return True
    ta, tb = set(normalize_title(a.title).split()), set(normalize_title(b.title).split())
    jaccard = len(ta & tb) / len(ta | tb) if ta | tb else 0.0
    same_date = a.deadline and a.deadline == b.deadline
    return bool(same_date and (ratio >= 0.6 or jaccard >= 0.5))


def _richness(o: Opportunity) -> int:
    return len(o.summary) + 40 * len(o.tags) + (30 if o.deadline else 0) + (20 if o.event_date else 0)


@trace("dedupe_and_filter", run_type="chain")
def dedupe_and_filter(opps: list[Opportunity], today: date) -> tuple[list[Opportunity], dict]:
    stats = {"input": len(opps), "duplicates_removed": 0, "expired_removed": 0}
    live = []
    for o in opps:
        if o.deadline and date.fromisoformat(o.deadline) < today:
            stats["expired_removed"] += 1
            continue
        live.append(o)

    kept: list[Opportunity] = []
    for o in live:
        for i, existing in enumerate(kept):
            if is_duplicate(o, existing):
                stats["duplicates_removed"] += 1
                if _richness(o) > _richness(existing):   # keep the more informative copy
                    kept[i] = o
                break
        else:
            kept.append(o)
    stats["output"] = len(kept)
    return kept, stats
