"""Persist / render results (only when the user's consent allows storage)."""
from __future__ import annotations

import json
from datetime import datetime

from config import settings


def to_markdown(result: dict) -> str:
    lines = [f"# Personalised opportunities for `{result['user']}`", "",
             f"*Source: {result['source']} | LLM: {result['llm_used']} | "
             f"Diversity: {result['metrics']}*", ""]
    for i, rec in enumerate(result["recommendations"], 1):
        o = rec["opportunity"]
        lines += [f"## {i}. {o['title']}  ({o['category']}, score {rec['score']})",
                  f"- Link: {o['url']}", f"- Deadline: {o['deadline'] or 'n/a'} | Mode: {o['mode']} | Location: {o['location'] or 'n/a'}",
                  f"- Tags: {', '.join(o['tags']) or 'n/a'}", f"- Why: {rec['reason']}", ""]
    return "\n".join(lines)


def save(result: dict) -> list[str]:
    settings.output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = settings.output_dir / f"{result['user']}_{stamp}"
    base.with_suffix(".json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    base.with_suffix(".md").write_text(to_markdown(result), encoding="utf-8")
    return [str(base.with_suffix(".json")), str(base.with_suffix(".md"))]
