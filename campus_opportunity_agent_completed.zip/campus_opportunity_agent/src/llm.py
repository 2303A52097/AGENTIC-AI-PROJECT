"""LLM factory - OpenRouter / OpenAI / Groq / Gemini behind one function."""
from __future__ import annotations

import os

from config import settings

_KEYS = {
    "openrouter": "OPENROUTER_API_KEY",
    "openai": "OPENAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "google": "GOOGLE_API_KEY",
}


def llm_available() -> bool:
    if os.getenv("OPENROUTER_API_KEY"):
        return True
    return bool(os.getenv(_KEYS.get(settings.llm_provider, "OPENAI_API_KEY")))


def get_llm(temperature: float = 0.2):
    """Return a LangChain chat model, or None when no API key is configured."""
    if not llm_available():
        return None
    provider = settings.llm_provider

    if provider == "openrouter" or (os.getenv("OPENROUTER_API_KEY") and not os.getenv("OPENAI_API_KEY")):
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=os.getenv("OPENROUTER_API_KEY"),
            model=settings.openrouter_model,
            temperature=temperature,
        )

    if provider == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=settings.openai_model, temperature=temperature)

    if provider == "groq":
        from langchain_groq import ChatGroq
        return ChatGroq(model=settings.groq_model, temperature=temperature)

    if provider == "google":
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(model=settings.google_model, temperature=temperature)

    raise ValueError(f"Unknown LLM_PROVIDER: {provider}")
