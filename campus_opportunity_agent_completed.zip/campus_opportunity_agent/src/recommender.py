"""Explanation step: personalised 'why this fits you' text (LLM with template fallback)."""
from __future__ import annotations

from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

from src.privacy import redact_text
from src.schemas import Recommendation, SafeProfile
from src.tracing import trace


class Reason(BaseModel):
    index: int = Field(description="0-based index of the opportunity in the given list")
    reason: str = Field(description="One or two sentences, second person, specific to this student")


class Reasons(BaseModel):
    reasons: list[Reason]


def template_reason(rec: Recommendation, sp: SafeProfile) -> str:
    b, o = rec.score_breakdown, rec.opportunity
    bits = []
    if b.get("interest", 0) >= 0.6:
        bits.append("it matches your interests")
    if b.get("skills", 0) >= 0.6:
        bits.append("it uses skills you already have")
    if b.get("category", 0) == 1.0:
        bits.append(f"{o.category}s are a category you prefer")
    if b.get("eligibility", 0) == 1.0 and o.eligibility_years:
        bits.append(f"it is meant for year {sp.year} students")
    if o.deadline:
        bits.append(f"the deadline is {o.deadline}")
    return ("Recommended because " + ", ".join(bits) + ".") if bits else "A broader option that adds variety to your list."


PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You are a friendly career mentor. For each opportunity write 1-2 sentences explaining why it fits THIS student. "
     "Be specific (mention matching skills/interests, eligibility, deadline). Do not invent facts."),
    ("human", "Student (anonymous): {profile}\n\nOpportunities:\n{items}"),
])


@trace("explain", run_type="chain")
def add_reasons(recs: list[Recommendation], sp: SafeProfile, llm=None) -> list[Recommendation]:
    for r in recs:
        r.reason = template_reason(r, sp)
    if llm is None or not recs:
        return recs
    items = "\n".join(
        f"[{i}] {r.opportunity.title} ({r.opportunity.category}) tags={r.opportunity.tags} "
        f"deadline={r.opportunity.deadline} summary={redact_text(r.opportunity.summary)}"
        for i, r in enumerate(recs)
    )
    try:
        out = (PROMPT | llm.with_structured_output(Reasons)).invoke({"profile": sp.model_dump_json(), "items": items})
        for item in out.reasons:
            if 0 <= item.index < len(recs):
                recs[item.index].reason = item.reason
    except Exception as exc:
        print(f"[warn] LLM explanation failed, using template reasons: {exc}")
    return recs
