"""The agent pipeline (orchestrator).

profile -> privacy gate -> Scout (Tavily) -> Extract -> Dedupe/Filter -> Match -> Diversify -> Explain
        -> privacy output check -> save (if consented)      [every step is a LangSmith span]
"""
from __future__ import annotations

import json

from config import today
from src import collector, dedupe, diversity, extractor, matcher, privacy, recommender, report
from src.llm import get_llm
from src.schemas import StudentProfile
from src.tracing import trace


def _safe_trace_inputs(inputs: dict) -> dict:
    """LangSmith must never receive the raw profile (PII): log only the pseudonymous id + run options."""
    profile = inputs.get("profile")
    return {
        "pseudo_id": privacy.pseudonymize(profile.user_id) if profile is not None else None,
        "offline": inputs.get("offline"),
        "top_k": inputs.get("top_k"),
    }


class OpportunityAgent:
    def __init__(self, use_llm: bool = True):
        self.llm = get_llm() if use_llm else None

    @trace("campus_opportunity_agent", run_type="chain", process_inputs=_safe_trace_inputs)
    def run(self, profile: StudentProfile, offline: bool = False, top_k: int = 8,
            save: bool = True, diversity_lambda: float = 0.7) -> dict:
        policy = privacy.runtime_policy(profile)
        safe = privacy.build_safe_profile(profile)                         # 1. PRIVACY GATE
        llm = self.llm if policy["allow_llm"] else None
        privacy.audit(safe.pseudo_id, "run_started", llm=bool(llm), web=policy["allow_web_search"] and not offline)

        raw, source = collector.collect(safe, llm=llm, offline=offline, allow_web=policy["allow_web_search"])  # 2. SCOUT
        opps = extractor.extract_all(raw, llm=llm)                         # 3. EXTRACT
        clean, stats = dedupe.dedupe_and_filter(opps, today())             # 4. CLEAN
        ranked = matcher.rank(clean, safe, today())                        # 5. MATCH
        top = diversity.mmr_rerank(ranked, k=top_k, lam=diversity_lambda)  # 6. DIVERSIFY
        top = recommender.add_reasons(top, safe, llm=llm)                  # 7. EXPLAIN

        opp_list = [r.opportunity for r in top]
        result = {
            "user": safe.pseudo_id,
            "source": source,
            "llm_used": bool(llm),
            "stats": {"raw_results": len(raw), "extracted": len(opps), **stats},
            "metrics": {
                "category_coverage": diversity.category_coverage(opp_list),
                "intra_list_diversity": diversity.intra_list_diversity(opp_list),
                "category_entropy": diversity.category_entropy(opp_list),
                "source_diversity": diversity.source_diversity(opp_list),
            },
            "recommendations": [r.model_dump() for r in top],
        }

        # 8. OUTPUT PRIVACY CHECK
        leaks = privacy.find_leaks(json.dumps(result), profile)
        if leaks:
            raise RuntimeError("Privacy guard blocked output: private data detected in recommendations")
        result["privacy"] = {"leaks_found": 0, "policy": policy}

        if save and policy["allow_storage"]:                               # 9. STORE (consent only)
            result["saved_to"] = report.save(result)
        privacy.audit(safe.pseudo_id, "run_finished", n=len(top), saved=bool(save and policy["allow_storage"]))
        return result
