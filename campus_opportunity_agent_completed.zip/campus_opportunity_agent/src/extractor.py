"""Extraction step: raw page snippet -> structured Opportunity (LLM structured output + heuristic fallback)."""
from __future__ import annotations

import re
from urllib.parse import urlparse

from dateutil import parser as dateparser
from langchain_core.prompts import ChatPromptTemplate

from config import today
from src.privacy import redact_text
from src.schemas import Opportunity
from src.tracing import trace

CATEGORY_KEYWORDS = [
    ("hackathon", ["hackathon", "hack-a-thon", "buildathon"]),
    ("internship", ["internship", "intern ", "trainee", "co-op", "hiring", "campus drive"]),
    ("scholarship", ["scholarship", "fellowship", "grant"]),
    ("workshop", ["workshop", "bootcamp", "webinar", "seminar", "masterclass", "training"]),
    ("club", ["club", "society", "chapter", "recruitment", "volunteers"]),
    ("event", ["event", "competition", "fest", "summit", "meetup", "ctf", "pitch", "exhibition", "conference", "program"]),
]
ACTION_WORDS = ["apply", "register", "registration", "deadline", "recruit", "enroll", "join", "last date", "applications"]
TAG_VOCAB = [
    "python", "java", "javascript", "react", "sql", "machine learning", "deep learning", "ai", "llm", "langchain",
    "agentic ai", "agents", "data science", "kaggle", "cybersecurity", "ctf", "cloud", "aws", "docker", "devops",
    "robotics", "embedded", "iot", "web development", "entrepreneurship", "startup", "open source", "github",
    "design", "photography", "aptitude", "communication", "pytorch", "tensorflow", "nlp", "blockchain", "ui/ux",
]
CITIES = ["Hyderabad", "Bengaluru", "Bangalore", "Chennai", "Mumbai", "Pune", "Delhi", "Kolkata", "Warangal", "Remote"]

_MONTH = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*"
DATE_RE = (rf"(?:\d{{1,2}}(?:st|nd|rd|th)?\s+{_MONTH}\.?,?\s+\d{{4}}"
           rf"|{_MONTH}\.?\s+\d{{1,2}}(?:st|nd|rd|th)?,?\s+\d{{4}}|\d{{4}}-\d{{2}}-\d{{2}})")
DEADLINE_KW = r"(?:apply by|apply before|register by|registration by|join by|join before|deadline|closes|close on|till|until|last date|applications? close)"
EVENT_KW = r"(?:event on|held on|takes place on|starts on|happening on|scheduled for)"


def _domain(url: str) -> str:
    return urlparse(url).netloc.lower().removeprefix("www.")


def _organization(url: str) -> str:
    parts = _domain(url).split(".")
    if len(parts) >= 3 and parts[-2] in {"co", "ac", "edu", "org", "com", "gov"}:
        return parts[-3]
    return parts[-2] if len(parts) >= 2 else parts[0]


def _find_date(text: str, kw_pattern: str) -> str | None:
    text = re.sub(rf"(\d{{1,2}})\s*[-–]\s*\d{{1,2}}(\s+{_MONTH})", r"\1\2", text)  # "6-7 December" -> "6 December"
    m = re.search(rf"{kw_pattern}[^.\d]{{0,25}}({DATE_RE})", text, flags=re.IGNORECASE)
    if not m:
        return None
    try:
        return dateparser.parse(m.group(1), dayfirst=True).date().isoformat()
    except (ValueError, OverflowError):
        return None


def heuristic_extract(raw: dict) -> Opportunity:
    """Rule-based extractor: works offline, used as a fallback when the LLM is unavailable."""
    title, content, url = raw.get("title", ""), raw.get("content", ""), raw.get("url", "")
    text = f"{title}. {content}"
    low = text.lower()

    category = "other"
    for cat, words in CATEGORY_KEYWORDS:
        if any(w in low for w in words):
            category = cat
            break
    is_opp = category != "other" and any(w in low for w in ACTION_WORDS)

    tags = [t for t in TAG_VOCAB if re.search(rf"(?<![a-z]){re.escape(t)}(?![a-z])", low)]
    years: set[int] = set()
    if re.search(r"pre-?\s?final", low):
        years.add(3)
    if re.search(r"(?<!pre-)(?<!pre )final[- ]year", low):
        years.add(4)
    if "year" in low:
        for num, pat in ((1, r"\b(first|1st)\b"), (2, r"\b(second|2nd)\b"), (3, r"\b(third|3rd)\b"), (4, r"\b(fourth|4th)\b")):
            if re.search(pat, low):
                years.add(num)
    if re.search(r"\bfreshers?\b", low):
        years.add(1)
    if re.search(r"all years|every year|open to all", low):
        years = set()

    online = bool(re.search(r"remote|online|virtual", low))
    onsite = bool(re.search(r"on-?site|in-?person|campus|offline", low))
    mode = "hybrid" if online and onsite else "online" if online else "offline" if onsite else "unknown"
    location = next((c for c in CITIES if c.lower() in low and c != "Remote"), "")

    sentences = re.split(r"(?<=[.!?])\s+", content.strip())
    return Opportunity(
        is_opportunity=is_opp,
        title=title.strip(),
        category=category,
        organization=_organization(url),
        url=url,
        summary=" ".join(sentences[:2])[:300],
        deadline=_find_date(text, DEADLINE_KW),
        event_date=_find_date(text, EVENT_KW),
        location=location,
        mode=mode,
        tags=tags,
        eligibility_years=sorted(years),
        source_domain=_domain(url),
    )


EXTRACT_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You extract structured data about student opportunities from web search results. Today is {today}. "
     "Set is_opportunity=false for generic articles, listicles, or pages that are not a concrete event, "
     "internship, hackathon, workshop, club, or scholarship. Dates must be ISO (YYYY-MM-DD) and only filled "
     "when stated in the text - never guess. Tags are short lowercase skill/topic keywords. "
     "eligibility_years is empty when open to everyone."),
    ("human", "Title: {title}\nURL: {url}\nContent: {content}"),
])


@trace("extract_one", run_type="chain")
def llm_extract(raw: dict, llm) -> Opportunity:
    chain = EXTRACT_PROMPT | llm.with_structured_output(Opportunity)
    opp = chain.invoke({
        "today": today().isoformat(),
        "title": redact_text(raw.get("title", "")),
        "url": raw.get("url", ""),
        "content": redact_text(raw.get("content", ""))[:1800],
    })
    opp.url = raw.get("url", "")
    opp.source_domain = _domain(opp.url)
    return opp


@trace("extract", run_type="chain")
def extract_all(raw_results: list[dict], llm=None) -> list[Opportunity]:
    """Convert every raw result to an Opportunity; drop non-opportunities."""
    opportunities: list[Opportunity] = []
    for raw in raw_results:
        if not raw.get("url"):
            continue
        opp = None
        if llm is not None:
            try:
                opp = llm_extract(raw, llm)
            except Exception as exc:
                print(f"[warn] LLM extraction failed for {raw.get('url')}: {exc}")
        if opp is None:
            opp = heuristic_extract(raw)
        if opp.is_opportunity and opp.title:
            opportunities.append(opp)
    return opportunities
