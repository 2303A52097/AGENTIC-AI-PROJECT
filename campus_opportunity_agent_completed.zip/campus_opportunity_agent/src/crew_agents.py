"""OPTIONAL multi-agent layer with CrewAI (python main.py run --crew).

Three specialised agents collaborate sequentially:
  Scout    -> searches the web (Tavily) for raw opportunities
  Analyst  -> runs our extraction/dedupe/matching pipeline as a tool and verifies fit
  Advisor  -> writes the final, friendly action plan (what to apply to first, and why)

The deterministic pipeline (src/pipeline.py) stays the source of truth for ranking;
CrewAI adds the collaborative, narrative layer. Only the SAFE (PII-free) profile is passed in.
"""
from __future__ import annotations

import json

from config import settings
from src.schemas import SafeProfile


def run_crew(safe: SafeProfile, pipeline_result: dict) -> str:
    try:
        from crewai import Agent, Crew, LLM, Process, Task
        from crewai.tools import tool
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("CrewAI not installed. Run: pip install crewai") from exc

    from src.tools import search_tavily

    @tool("tavily_web_search")
    def web_search(query: str) -> str:
        """Search the web for student opportunities (events, internships, clubs, scholarships)."""
        try:
            return json.dumps(search_tavily(query, max_results=4))[:4000]
        except Exception as exc:
            return f"search failed: {exc}"

    @tool("ranked_opportunities")
    def ranked_opportunities(_: str = "") -> str:
        """Return the already cleaned, de-duplicated and ranked opportunities as JSON."""
        slim = [{"title": r["opportunity"]["title"], "category": r["opportunity"]["category"],
                 "deadline": r["opportunity"]["deadline"], "score": r["score"], "url": r["opportunity"]["url"]}
                for r in pipeline_result["recommendations"]]
        return json.dumps(slim)

    llm = LLM(model=settings.crewai_model, temperature=0.2)
    profile_json = safe.model_dump_json()

    scout = Agent(role="Opportunity Scout", goal="Find fresh events, internships and clubs for the student",
                  backstory="You know where campus news and openings are posted.", tools=[web_search], llm=llm, verbose=False)
    analyst = Agent(role="Fit Analyst", goal="Judge how well each opportunity fits the student's profile",
                    backstory="You are strict about eligibility and deadlines.", tools=[ranked_opportunities], llm=llm, verbose=False)
    advisor = Agent(role="Career Advisor", goal="Turn the analysis into a clear weekly action plan",
                    backstory="You mentor students kindly and concretely.", llm=llm, verbose=False)

    t1 = Task(description=f"Student (anonymous): {profile_json}. Run 2 web searches for gaps not yet covered "
                          "(e.g. scholarships or clubs) and list any extra promising leads.",
              expected_output="Bullet list of extra leads with URLs", agent=scout)
    t2 = Task(description="Use ranked_opportunities. Flag the best 5 fits and any with a deadline within 14 days.",
              expected_output="Short analysis of top 5 with urgency flags", agent=analyst, context=[t1])
    t3 = Task(description="Write a prioritised action plan (what to do this week / this month). Never ask for personal data.",
              expected_output="Markdown action plan", agent=advisor, context=[t1, t2])

    crew = Crew(agents=[scout, analyst, advisor], tasks=[t1, t2, t3], process=Process.sequential, verbose=False)
    return str(crew.kickoff())
