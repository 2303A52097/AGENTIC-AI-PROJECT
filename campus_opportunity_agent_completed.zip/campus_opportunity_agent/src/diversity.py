"""Diversity: similarity, MMR re-ranking and list-level diversity metrics."""
from __future__ import annotations

import math
from collections import Counter

from src.schemas import Opportunity, Recommendation
from src.tracing import trace


def similarity(a: Opportunity, b: Opportunity) -> float:
    ta, tb = set(a.tags), set(b.tags)
    jaccard = len(ta & tb) / len(ta | tb) if ta | tb else 0.0
    return 0.45 * (a.category == b.category) + 0.35 * jaccard + 0.20 * (a.source_domain == b.source_domain)


@trace("diversify_mmr", run_type="chain")
def mmr_rerank(recs: list[Recommendation], k: int, lam: float = 0.7) -> list[Recommendation]:
    """Maximal Marginal Relevance: lam*relevance - (1-lam)*max similarity to already selected items."""
    pool, selected = list(recs), []
    while pool and len(selected) < k:
        def mmr(r: Recommendation) -> float:
            redundancy = max((similarity(r.opportunity, s.opportunity) for s in selected), default=0.0)
            return lam * r.score - (1 - lam) * redundancy
        best = max(pool, key=mmr)
        selected.append(best)
        pool.remove(best)
    return selected


# ------------------------------------------------------------------ metrics
def category_coverage(opps: list[Opportunity], target: int = 4) -> float:
    return min(1.0, len({o.category for o in opps}) / target) if opps else 0.0


def intra_list_diversity(opps: list[Opportunity]) -> float:
    """1 - mean pairwise similarity (higher = more diverse)."""
    n = len(opps)
    if n < 2:
        return 0.0
    sims = [similarity(opps[i], opps[j]) for i in range(n) for j in range(i + 1, n)]
    return round(1 - sum(sims) / len(sims), 4)


def category_entropy(opps: list[Opportunity]) -> float:
    """Normalised Shannon entropy of the category distribution (0..1)."""
    if len(opps) < 2:
        return 0.0
    counts = Counter(o.category for o in opps)
    probs = [c / len(opps) for c in counts.values()]
    h = -sum(p * math.log2(p) for p in probs)
    return round(h / math.log2(len(opps)), 4)


def source_diversity(opps: list[Opportunity]) -> float:
    return round(len({o.source_domain for o in opps}) / len(opps), 4) if opps else 0.0
