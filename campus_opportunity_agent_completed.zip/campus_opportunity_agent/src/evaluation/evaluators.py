"""Evaluators for relevance, diversity, duplicates, freshness and privacy.

Signature (run, example) -> dict is the LangSmith `evaluate()` convention; the same functions are reused
for the local fallback runner, so numbers are identical with or without a LangSmith account.
"""
from __future__ import annotations

import json
import math
from datetime import date

from config import today
from src import privacy
from src.dedupe import normalize_url
from src.diversity import category_coverage, category_entropy, intra_list_diversity, source_diversity
from src.schemas import Opportunity, StudentProfile


def _opps(run) -> list[Opportunity]:
    return [Opportunity(**r["opportunity"]) for r in (run.outputs or {}).get("recommendations", [])]


def _is_relevant(o: Opportunity, expected: dict) -> int:
    tag_hit = bool(set(t.lower() for t in o.tags) & set(t.lower() for t in expected.get("relevant_tags", [])))
    cat_hit = o.category in expected.get("relevant_categories", [])
    return int(tag_hit and cat_hit)  # must match topic AND preferred category


# --------------------------------------------------------------- relevance
def precision_at_k(run, example) -> dict:
    opps = _opps(run)
    if not opps:
        return {"key": "precision_at_k", "score": 0.0}
    rel = [_is_relevant(o, example.outputs) for o in opps]
    return {"key": "precision_at_k", "score": round(sum(rel) / len(rel), 4)}


def ndcg(run, example) -> dict:
    opps = _opps(run)
    rel = [_is_relevant(o, example.outputs) for o in opps]
    dcg = sum(r / math.log2(i + 2) for i, r in enumerate(rel))
    ideal = sorted(rel, reverse=True)
    idcg = sum(r / math.log2(i + 2) for i, r in enumerate(ideal))
    return {"key": "ndcg", "score": round(dcg / idcg, 4) if idcg else 0.0}


def eligibility_ok(run, example) -> dict:
    """No recommendation should exclude the student's study year."""
    year = example.inputs["profile"]["year"]
    opps = _opps(run)
    bad = [o for o in opps if o.eligibility_years and year not in o.eligibility_years]
    return {"key": "eligibility_ok", "score": round(1 - len(bad) / len(opps), 4) if opps else 0.0}


# --------------------------------------------------------------- diversity
def diversity_scores(run, example) -> dict:
    opps = _opps(run)
    return {"results": [
        {"key": "category_coverage", "score": category_coverage(opps)},
        {"key": "intra_list_diversity", "score": intra_list_diversity(opps)},
        {"key": "category_entropy", "score": category_entropy(opps)},
        {"key": "source_diversity", "score": source_diversity(opps)},
    ]}


# --------------------------------------------------------------- hygiene
def duplicate_free(run, example) -> dict:
    opps = _opps(run)
    urls = {normalize_url(o.url) for o in opps}
    return {"key": "duplicate_free", "score": round(len(urls) / len(opps), 4) if opps else 1.0}


def not_expired(run, example) -> dict:
    opps = _opps(run)
    bad = [o for o in opps if o.deadline and date.fromisoformat(o.deadline) < today()]
    return {"key": "not_expired", "score": 0.0 if bad else 1.0}


# --------------------------------------------------------------- privacy
def privacy_safe(run, example) -> dict:
    """Synthetic profiles contain fake PII; it must not appear anywhere in the output."""
    profile = StudentProfile(**example.inputs["profile"])
    leaks = privacy.find_leaks(json.dumps(run.outputs or {}), profile)
    return {"key": "privacy_safe", "score": 0.0 if leaks else 1.0, "comment": ", ".join(leaks)}


# ------------------------------------------------------ optional LLM-as-judge
def make_llm_judge():
    """LLM judge scores how well the top recommendations fit the profile (1-5 -> 0..1)."""
    from pydantic import BaseModel, Field

    from src.llm import get_llm

    llm = get_llm(temperature=0)
    if llm is None:
        return None

    class Grade(BaseModel):
        score: int = Field(ge=1, le=5, description="1 = irrelevant, 5 = excellent fit")
        explanation: str

    judge = llm.with_structured_output(Grade)

    def llm_relevance_judge(run, example) -> dict:
        p = example.inputs["profile"]
        safe = {k: p[k] for k in ("degree", "year", "interests", "skills", "goals", "preferred_categories")}
        items = [f"- {o.title} ({o.category}) tags={o.tags} eligible_years={o.eligibility_years}" for o in _opps(run)]
        g = judge.invoke(f"Student: {json.dumps(safe)}\nRecommended list:\n" + "\n".join(items) +
                         "\nRate how relevant and well-targeted this list is for the student.")
        return {"key": "llm_relevance_judge", "score": (g.score - 1) / 4, "comment": g.explanation}

    return llm_relevance_judge


ALL_EVALUATORS = [precision_at_k, ndcg, eligibility_ok, diversity_scores, duplicate_free, not_expired, privacy_safe]
