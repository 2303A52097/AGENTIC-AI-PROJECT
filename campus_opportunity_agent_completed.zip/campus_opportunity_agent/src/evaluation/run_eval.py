"""Create the LangSmith dataset and run the evaluation experiment (or a local fallback)."""
from __future__ import annotations

import json
import os
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

from rich.console import Console
from rich.table import Table

from config import settings
from src.evaluation.evaluators import ALL_EVALUATORS, make_llm_judge
from src.pipeline import OpportunityAgent
from src.schemas import StudentProfile

DATASET_NAME = "campus-opportunity-eval-v1"
DATA_FILE = settings.data_dir / "eval_dataset.json"
console = Console()


def _load_cases(dataset_path: str | None = None) -> list[dict]:
    p = Path(dataset_path) if dataset_path else DATA_FILE
    if not p.is_absolute():
        if (settings.root / p).exists():
            p = settings.root / p
        elif (settings.data_dir / p).exists():
            p = settings.data_dir / p
    if not p.exists():
        p = settings.data_dir / "eval_dataset.json"

    if p.suffix.lower() == ".jsonl":
        cases = []
        with p.open(encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                row = json.loads(line)
                cases.append({
                    "name": row.get("metadata", {}).get("case", f"case_{len(cases)+1}"),
                    "profile": row.get("inputs", {}).get("profile", {}),
                    "relevant_tags": row.get("outputs", {}).get("relevant_tags", []),
                    "relevant_categories": row.get("outputs", {}).get("relevant_categories", []),
                })
        return cases
    return json.loads(p.read_text(encoding="utf-8"))


def make_target(use_llm: bool, offline: bool, top_k: int):
    agent = OpportunityAgent(use_llm=use_llm)

    def target(inputs: dict) -> dict:
        profile = StudentProfile(**inputs["profile"])
        result = agent.run(profile, offline=offline, top_k=top_k, save=False)
        return {"recommendations": result["recommendations"], "metrics": result["metrics"], "stats": result["stats"]}

    return target


# ------------------------------------------------------------- LangSmith dataset
def ensure_dataset(client, cases: list[dict] | None = None):
    """Create (or reuse) the dataset: inputs = synthetic profile, outputs = relevance ground truth."""
    if client.has_dataset(dataset_name=DATASET_NAME):
        return client.read_dataset(dataset_name=DATASET_NAME)
    ds = client.create_dataset(DATASET_NAME, description="Synthetic student profiles + expected relevant tags/categories "
                                                         "for the campus opportunity recommender. Contains NO real PII.")
    cases = cases or _load_cases()
    client.create_examples(
        dataset_id=ds.id,
        inputs=[{"profile": c["profile"]} for c in cases],
        outputs=[{"relevant_tags": c["relevant_tags"], "relevant_categories": c["relevant_categories"]} for c in cases],
        metadata=[{"case": c["name"]} for c in cases],
    )
    console.print(f"[green]Created LangSmith dataset[/green] {DATASET_NAME} with {len(cases)} examples")
    return ds


def run_langsmith(use_llm: bool, offline: bool, top_k: int, judge: bool, dataset: str | None = None):
    from langsmith import Client, evaluate

    client = Client()
    cases = _load_cases(dataset)
    ensure_dataset(client, cases)
    evaluators = list(ALL_EVALUATORS) + ([j] if judge and (j := make_llm_judge()) else [])
    results = evaluate(
        make_target(use_llm, offline, top_k),
        data=DATASET_NAME,
        evaluators=evaluators,
        experiment_prefix="campus-reco",
        max_concurrency=1,
        metadata={"top_k": top_k, "offline": offline, "llm": use_llm},
    )
    console.print("[bold green]Experiment finished.[/bold green] Open LangSmith -> Datasets & Experiments to compare runs.")
    return results


# ------------------------------------------------------------- local fallback
def run_local(use_llm: bool, offline: bool, top_k: int, judge: bool, dataset: str | None = None) -> dict:
    cases = _load_cases(dataset)
    target = make_target(use_llm, offline, top_k)
    evaluators = list(ALL_EVALUATORS) + ([j] if judge and (j := make_llm_judge()) else [])
    scores: dict[str, list[float]] = defaultdict(list)
    for case in cases:
        inputs = {"profile": case["profile"]}
        run = SimpleNamespace(outputs=target(inputs))
        example = SimpleNamespace(inputs=inputs, outputs={"relevant_tags": case["relevant_tags"],
                                                          "relevant_categories": case["relevant_categories"]})
        for ev in evaluators:
            out = ev(run, example)
            for item in out.get("results", [out]):
                scores[item["key"]].append(item["score"])
    summary = {k: round(sum(v) / len(v), 4) for k, v in scores.items()}
    table = Table(title=f"Local evaluation (mean over {len(cases)} cases in dataset)")
    table.add_column("metric"), table.add_column("score", justify="right")
    for k, v in summary.items():
        table.add_row(k, f"{v:.3f}")
    console.print(table)
    return summary


def main(langsmith: bool, use_llm: bool, offline: bool, top_k: int, judge: bool, dataset: str | None = None):
    if langsmith:
        if not os.getenv("LANGSMITH_API_KEY"):
            raise SystemExit("LANGSMITH_API_KEY missing in .env - add it or run without --langsmith")
        os.environ.setdefault("LANGSMITH_TRACING", "true")
        return run_langsmith(use_llm, offline, top_k, judge, dataset)
    return run_local(use_llm, offline, top_k, judge, dataset)
